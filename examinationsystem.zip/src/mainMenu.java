import view.LoginView;

public class mainMenu {
    public static void main(String[] args) {
        new LoginView().LoginMenu();
    }
}
