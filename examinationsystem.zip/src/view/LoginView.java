package view;
import dao.QuestionDao;
import pojo.User;
import service.ExaminationService;
import service.Impl.*;
import service.MenuService;
import service.UserService;
import service.WrongSetService;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.InputMismatchException;
import java.util.Scanner;

public class LoginView {
    /**
     * 主界面展示：
     *                ---------------------------------
     *                欢迎来到考试系统！
     *                请选择：
     *                1. 登录账号
     *                2. 注册账号
     *                3. 退出程序
     *                ---------------------------------
     *                请输入需要执行的功能[请输入数字1-3]：
     * 功能流程：
     *         用户输入序号，执行相应功能
     *         先用do-while循环显示主界面
     *                  执行显示初始界面功能，通过控制台打印。
     *         输入数字1：登录
     *                 执行登录功能：
     *                      调用LoginView类中的userLoginView()方法，进入登录界面。
     *          输入数字2：注册
     *                  执行注册功能：调用MenuService类中的Register()函数，返回true/false

     *           输入数字3：退出
     *                  直接退出程序，将退出条件置为false即可。
    */
    public void LoginMenu(){
        //建立主页面菜单
        String Menu = "---------------------------------\n" +
                " 欢迎来到考试系统！\n" +
                " 请选择：\n" +
                " 1. 登录账号\n" +
                " 2. 注册账号\n" +
                " 3. 退出程序\n" +
                "---------------------------------\n" +
                " 请输入需要执行的功能[请输入数字1-3]：";

        //当前系统状态
        boolean run = true;
        //注册账号username，密码password，再一次输入密码passwords；
        String username, password, passwords;
        //进入循环
        do {
            //打印主菜单
            System.out.println(Menu);
            //接收用户输入
            int userInput = 0;
            try {
                Scanner s = new Scanner(System.in);
                //获取用户输入
                userInput = s.nextInt();
            } catch (Exception e) {
                System.out.println("您的输入有误，请重新输入！");
            }
            //当用户输入1时，调用登录方法进行登录。
            if (userInput == 1){
                userLoginView();
                run = false;
            }
            /*当用户输入2时，获取用户输入注册信息，并将输入信息传输到验证信息函数
            Register(),进行信息验证
             */
            else if (userInput == 2){
                userRegisterView();
                run = false;
            }
            //当用户输入3时，退出系统
            else if (userInput == 3){
                System.out.println("感谢您使用--萌萌新考试系统--");
                return;
            }
            //用户非法输入，重新进行循环。
            else{
                System.out.println("您的输入有误，请重新输入！");
            }
        }while(run);
    }

    /**
     * 用户登录界面展示：
     *      功能流程：
     *          提示请输入用户名和密码，调用MenuService类中的login()函数，返回true/false
     *          如果返回true，表示登录成功，跳转至考试界面：调用LoginView类中的ShowExaminationMenu(userName)函数，需要传入用户名
     *          如果返回false，表示登录失败，跳转回主界面。
     */
    public void userLoginView(){
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入用户名：");
        String userName = sc.next();
        System.out.println("请输入密码：");
        String passWord=sc.next();
        MenuServiceImplements x = new MenuServiceImplements();
        boolean b = x.Login(userName,passWord);
        if(b) {
            System.out.println("登录成功！");
            ShowExaminationMenu(userName);
        }
        else {
            System.out.println("用户名或密码不正确，请重新登录！");
            LoginMenu();
        }
    }

    /**
     * 用户注册界面展示：
     *      功能流程：
     *          提示请输入用户名、密码和确认密码，调用MenuService类中的Register()函数，返回true/false
     *          如果返回true，表示注册成功，跳转至登录界面，调用LoginView类中的userLoginView()函数
     *          如果返回false，表示注册失败，提示注册失败,并跳转至主界面
     */
    public void userRegisterView(){
        do {
            Scanner myScanner = new Scanner(System.in);
            System.out.println("===请输入用户名(用户名长度应为6位)===");
            String userName = myScanner.next();
            System.out.println("===请输入密码 (密码长度应在6-8位)===");
            String passWord = myScanner.next();
            System.out.println("===请确认密码 (密码长度应在6-8位)===");
            String checkedPassWord = myScanner.next();

            MenuServiceImplements mm = new MenuServiceImplements();
            boolean register = mm.Register(userName, passWord, checkedPassWord);
            if(register) {
                System.out.println("***注册成功,请登录***");
                userLoginView();    //进入登录页面
                break;
            }
        }while (true);
    }

    /**
     * 考试界面展示：
     * ---------------------------------
     * 您好，xxx！
     * 请选择：
     * 1. 进入考试
     * 2. 刷题练习
     * 3. 查看考试排名
     * 4. 错题本
     * 5. 退出程序
     * ---------------------------------
     * 功能流程：
     *         先用do-while循环显示考试界面
     *                  执行显示初始界面功能，通过控制台打印。
     *         显示您好，xxx！
     *                  根据传入的参数userName，直接展示即可。
     *         输入数字1：进入考试
     *                  调用LoginView类中的examinationView(String userName)函数
     *          输入数字2：刷题练习
     *                  调用LoginView类中的practiceView()函数，进入测试
     *          输入数字3：查看排名
     *                  调用RecordService类中的viewRank()函数，自动返回主界面
     *          输入数字4：展示错题本
     *                   调用LoginView类中的wrongView()函数，
     *          输入数字5：直接退出程序，调用userService类中的saveUser函数，再return
     */
    public void ShowExaminationMenu(String userName){boolean exitExaminationMenu = true;     //退出考试界面的标志
        int choice = 0;
        do{
            System.out.println("---------------------------------");
            System.out.println("您好,用户：" + userName+"\t欢迎来到萌萌新考试系统" +
                    "\n请输入数字选择您要进行的操作");
            System.out.println("请选择：\n" + "1. 进入考试\n" + "2. 刷题练习\n" +
                    "3. 查看考试排名\n" + "4. 错题本\n" + "5. 退出程序");
            System.out.println("---------------------------------");
            try{
                Scanner intputScanner = new Scanner(System.in);
                choice = intputScanner.nextInt();
                switch (choice){
                    case 1:
                        examinationView(userName);
                        break;
                    case 2:
                        practiceView(userName);
                        break;
                    case 3:
                        new RecordServiceImplements().viewRank();
                        break;
                    case 4:
                        wrongView(userName);
                        break;
                    case 5:
                        System.out.println("感谢您使用--萌萌新考试系统--");
                        return;
                    default:
                        System.out.println("请您输入数字1-5以使用系统");
                }
            }catch (InputMismatchException inputMismatchException){
                System.out.println("请您输入数字1-5以使用系统");
            }
        }while(exitExaminationMenu);}

    /**
     * 进入考试界面显示
     *        ---------------------------------
     *        考生xxx，你现在即将进入计算机中级软件考试，考试时间为xx分钟
     *        考试前请阅读考试相关注意事项，诚信考试
     *        开考xx分钟内不得交卷
     *        考试页面操作：
     *        输入p返回上一题；输入n进入下一题；输入j+题号跳转题目；输入“交卷”可以提前交卷
     *        准备好后，输入s开始考试：
     *        ---------------------------------
     *      功能流程：
     *           接收键盘输入，如果输入s,进入下面功能。
     *           执行创建题目功能，调用ExaminationService类中的createExamination()函数，无返回值.
     *              执行显示题目功能：调用ExaminationService类中的viewExamination()函数，无返回值，展示第numberOfExminations题内容。
     *                  如果输入的是A、B、C、D选项或0，1(代表判断题)输入,0错误，1正确，调用ExaminationService类中的saveResult()函数，保存输入结果
     *                  输入p，numberOfExminations的值-1，重复调用ExaminationService类中的viewExamination()函数显示题目内容
     *                  输入n，numberOfExminations的值+1，重复调用ExaminationService类中的viewExamination()函数显示题目内容
     *                  输入j+题号，numberOfExminations的值设为输入的题号，重复调用ExaminationService类中的viewExamination()函数显示题目内容
     *                  输入“交卷”，显示结算界面，调用LoginView类中的recordOfExaminationView(String userName)函数显示成绩，退出考试.
     */
    public void examinationView(String userName){
        //用输出语句打印考试界面，考试时间到了就交卷(未写，加上)
        System.out.println("------------------------------");
        System.out.println("考生" + userName + "，\t" + "你现在即将进入计算机中级软件考试，考试时间为100分钟");
        System.out.println("考试前请阅读考试相关注意事项，诚信考试");
        System.out.println("考试页面操作：");
        System.out.println("输入p返回上一题；输入n进入下一题；输入j,然后输入题号跳转题目；输入“交卷”可以提前交卷");
        System.out.println("请输入您的选择，判断题0为错，1为对，选择题输入大小写均可");
        System.out.println("准备好后，输入s开始考试,没有准备好输入q可以退出:");
        System.out.println("-------------------------------");
        //定义一个变量用于接收用户输入的s
        Scanner sc = new Scanner(System.in);
        //记录现在的时间，便于倒计时
        LocalDateTime localDateTime;
        LocalDateTime localDateTimeEnd;
        ExaminationServiceImplements examinationService = null;
        try {
            while (true){
                String t = sc.nextLine();
                //对ExaminationServiceImplement实现类进行实例化
                examinationService = new ExaminationServiceImplements();
                //用if语句判断用户是否输入s开始考试
                if ("s".equals(t)) {
                    examinationService.createExamination(); //创建完题目跳出循环
                    localDateTime = LocalDateTime.now();    //开始计时
                    localDateTimeEnd = localDateTime.plusMinutes(10);    //给10分钟做题
                    break;
                }else if("q".equals(t)){
                    return;
                }else {
                    System.out.println("请您根据提示输入对应字母");
                }
            }
            //定义一个变量用于存储题目序号且初始化为1
            int numberOfExminations = 1;
            //count用于查看题目号是否发生变化
            int count = 0;
            //用while循环进行答案输入和换题操作
            while (true) {
                if(LocalDateTime.now().equals(localDateTimeEnd)){
                    System.out.println("考试时间到！正在结束考试…");
                    recordOfExaminationView(userName);
                    break;
                }
                //如果题目没改变不会重复打印
                if(count != numberOfExminations){
                    examinationService.viewExamination(numberOfExminations);
                }
                //变量input用于记录用户输入
                String input = sc.nextLine();
                //定义一个数组用于储放题目选项
                String[] option = {"A", "B", "C", "D", "a", "b", "c", "d", "0", "1"};
                //用for循环便利选项，判断用户输入了哪一个选项
                //用if判断语句判断判断用户的输入
                for (int i = 0; i < option.length; i++) {
                    if (input.equals(option[i])) {
                        if(input.equals("0") || input.equals("1")){
                            examinationService.saveResult(numberOfExminations, input);
                        }
                        examinationService.saveResult(numberOfExminations, input.toUpperCase());
                        //答完题设为一样，避免重复显示题目内容
                        count = numberOfExminations;
                        //比对好了跳出循环
                        break;
                    }
                }
                if ("p".equals(input)) {
                    if(numberOfExminations == 1){
                        System.out.println("当前已经为第一题！");
                        //变动不合理，不需要再显示一次题目
                        count = numberOfExminations;
                        continue;
                    }
                    //题目变动合理，就要显示，设为-1不会导致不显示
                    count = -1;
                    numberOfExminations--;
                } else if ("n".equals(input)) {
                    if(numberOfExminations == 55){
                        System.out.println("当前已经为最后一题！");
                        //变动不合理，不需要再显示一次题目
                        count = numberOfExminations;
                        continue;
                    }
                    //题目变动合理，就要显示，设为-1不会导致不显示
                    count = -1;
                    numberOfExminations++;
                } else if ("j".equals(input)) {
                    try {
                        int getNumber = sc.nextInt();
                        //吸收next导致的回车符
                        sc.nextLine();
                        if(getNumber < 1 || getNumber > QuestionDao.examinations.length){
                            System.out.println("您的输入超出题目范围，请您重新输入！");
                            //变动不合理，不需要再显示一次题目
                            count = numberOfExminations;
                            continue;
                        }
                        //题目变动合理，就要显示，设为-1不会导致不显示
                        count = -1;
                        numberOfExminations = getNumber;
                    } catch (Exception e) {
                        System.out.println("您的输入超出题目范围，请您重新输入！");
                        //变动不合理，不需要再显示一次题目
                        count = numberOfExminations;
                    }
                } else if ("交卷".equals(input)) {
                    recordOfExaminationView(userName);
                    break;
                } else if(!("ABCDabcd01".contains(input))){
                    System.out.println("请根据提示规范答案内容！");
                }
            }
        } catch (InputMismatchException inputMismatchException) {
            System.out.println("请输入s开始考试，输入q退出考试");
        }
    }

    /**
     * 考试结束结算界面显示内容：
     *      答题结束！
     *      您的得分是：xx分
     *      是否保存答题结果（回车默认保存，输入其他数值则不保存）？
     * 功能流程：
     *          显示考试成绩调用ExaminationService类中的getRecord()函数，返回int类型的分数。显示上述结算内容
     *          用户输入回车后保存结果，输入其他不保存，保存信息调用UserService类中的saveFinalRecord()函数。
     */
    public void recordOfExaminationView(String userName){
        System.out.println("答题结束!");
        /*下面为得分情况*/
        ExaminationServiceImplements examinationService = new ExaminationServiceImplements();//根据方法获取分数
        int score = examinationService.getRecord(userName);
        System.out.println("您的得分为：" + score);
        /*下面为保存信息*/
        System.out.println("是否保存信息？输入回车保存信息，任意键退出。");
        /* 接收用户输入的信息*/
        Scanner scanner = new Scanner(System.in);
        String gerSystemin = scanner.nextLine();
        /*判断是否保存信息*/
        if(gerSystemin.equals("")){
            UserServiceImplements userService1 = new UserServiceImplements();
            userService1.saveFinalRecord(score, userName);
        }else{
            System.out.println("您的考试信息未保存，已退出本次考试，感谢您的参与！");
        }
    }

    /**
     * 进入练习模式后，选择题库（拓展）：
     * ---------------------------------
     * 1. 2022Java计算机二级考试真题
     * 2. 2022Python计算机二级考试真题
     * 3. 腾讯校招面试真题
     * 4. 华为校招面试真题
     *
     * 请选择：_
     * 功能流程：
     *      接收输入的选择，根据不同选择调用PracticeService类中的loadPratice(int choice)方法，加载不同的题库。
     *      再调用PracticeService类中的viewPractice(int numberOfExminations)方法，显示测试题
     *      提示请输入当前选择的结果，对输入进行判断；
     *              如果输入的是A、B、C、D选项或0，1(代表判断题)输入,0错误，1正确
     *                  调用PracticeService类中的checkError(int numberOfExminations, char input, String userName)函数，检查输入是否正确，
     *                  正确进入下一题，numberOfExminations+1,错误显示解析，调用PracticeService类中的getAnnotations(int numberOfExminations)函数。
     *              如果输入h，展示解析，调用PracticeService类中的getAnnotations(int numberOfExminations)函数
     *              输入p，numberOfExminations的值-1，重复调用调用PracticeService类中的viewPractice(int numberOfExminations)方法显示题目内容
     *              输入n，numberOfExminations的值+1，重复调用调用PracticeService类中的viewPractice(int numberOfExminations)方法显示题目内容
     */
    public void practiceView(String userName){
        System.out.println("---------------------------------");
        System.out.println("1. 2022Java计算机二级考试真题");
        System.out.println("2. 2022Python计算机二级考试真题");
        System.out.println("3. 腾讯校招面试真题");
        System.out.println("4. 华为校招面试真题");
        System.out.println("0. 返回主菜单");
        System.out.println("---------------------------------");

        Scanner iPraticeChoice  = new Scanner(System.in); //输入选择题库
        Scanner iChar  = new Scanner(System.in);//输入选项

        PracticeServiceImplements p = new PracticeServiceImplements();
        System.out.println("请输入数字选择题库：");
        int PraticeChoice = iPraticeChoice.nextInt();

        //输入0返回主菜单
        if (PraticeChoice == 0){
            return;
        }

        //加载题库，题库由用户输入的PraticeChoice参数确认
        p.loadPratice(PraticeChoice);

        //进入答题，默认从第一题开始，因此在这里先要调用一次，并给个给个参数1
        int numberOfExam = 1; //题目序号
        p.viewPractice(numberOfExam);

        while(true){
            System.out.println("请输入选择的结果，(请输入您的选择，判断题0为错，1为对，选择题输入大小写均可" +
                    "输入h查看解析，输入p返回上一题，输入n进入下一题，输入f退出系统)");
            //输入选项
            System.out.println("请输入您的选项：");
            String Char = iChar.nextLine();
            switch (Char) {
                //输入H直接显示解析
                case "h": case "H":
                    p.getAnnotations(numberOfExam);
                    continue;
                    //输入P返回上一题
                case "p": case "P":
                    if(numberOfExam == 1){
                        System.out.println("当前已经是第一题");
                        continue;
                    }
                    p.viewPractice(--numberOfExam);
                    continue;
                    //输入N进入下一题
                case "n": case "N":
                    if(!(new PracticeServiceImplements().chechHasNext(numberOfExam + 1))){
                        System.out.println("当前为最后一题!您可以输入 “交卷” 结束答题。");
                        continue;
                    }
                    p.viewPractice(++numberOfExam);
                    continue;
                    ////输入E退出答题
                    //case "e","E":
                case "f":
                    return;
                default:
                    //判断是否是其他的值
                    if (!(Char.equals("a") || Char.equals("b") || Char.equals("c") || Char.equals("d") ||
                            Char.equals("A") || Char.equals("B") || Char.equals("C") || Char.equals("D") ||
                            Char.equals("0") || Char.equals("1"))){
                        System.out.println("请根据要求规范您的答案");
                        continue;
                    }
                    String input = "";
                    if("ABCDabcd".contains(Char)){
                        input = Char.toUpperCase();
                    }
                    //答案正确，进入下一题
                    if (p.checkError(numberOfExam, input, userName)) {
                        p.viewPractice(++numberOfExam);
                    }
                    //答案错误，显示解析
                    else {
                        p.getAnnotations(numberOfExam);
                    }
                    continue;
            }
        }
    }

    /**
     * 显示用户对应的错题集的内容，并能对错题集进行修改
     *      调用WrongSetService类中的viewExamination()方法，展示错题集第numberOfExminations题内容
     *      提示请输入当前选择的结果，
     *          如果输入A、B、C、D，或0，1。调用WrongSetService类中的checkInput()函数，检查输入是否正确，正确进入下一题，错误显示解析，调用WrongSetService类中的getAnnotations()函数
     *          如果输入h，展示解析，调用WrongSetService类中的getAnnotations()函数
     *          输入p，numberOfExminations的值-1，重复调用调用WrongSetService类中的viewExamination()方法显示题目内容，做出选择
     *          输入n，numberOfExminations的值+1，重复调用调用WrongSetService类中的viewExamination()方法显示题目内容，做出选择
     */
    public void wrongView(String userName) {
        Scanner scanner = new Scanner(System.in);
        //新建一个对象便于之后在p,n,h时调用方法，做出选择
        LoginView choices = new LoginView();
        int numberOfExminations = 1;
        boolean flag = true;   //退出
        //可以输入的选择
        String getInput = "ABCDabcd01";
        int count = 0;
        WrongSetServiceImplements wrongSetService = new WrongSetServiceImplements();
        do {
            //判断错题集为空
            try {
                if (new WrongSetServiceImplements().checkWrongSetIsNull(userName)){
                    System.out.println("你的错题本中没有错题，已自动退出页面。");
                    break;
                }
            } catch (IOException ioException) {
                System.out.println("用户信息读取失败");
                break;
            } catch (ClassNotFoundException e) {
                System.out.println("用户信息读取失败");
                break;
            }
            int length = 0;
            //判断其他输入条件
            //调用viewExamination()方法，展示错题集第numberOfExminations题内容
            if(count != numberOfExminations){
                wrongSetService.viewExamination(numberOfExminations, userName);
                count = -1;
            }
            System.out.println("请输入选择的结果，(0代表判断题错误，1代表正确，A、B、C、D为选择题输入" +
                    "输入h查看解析，输入p返回上一题，输入n进入下一题，输入-删除错题，输入f退出系统)");
            //如果输入Aa、Bb、Cc、Dd，或0，1。调用WrongSetService类中的checkInput()函数，检查输入是否正确，正确进入下一题，
            String input = scanner.next();
            if(input.length() != 1){{
                System.out.println("请根据提示输入规范的答案");
                count = numberOfExminations;
            }}
            if (getInput.contains(input)) {
                String inputResult = input.toUpperCase();
                new WrongSetServiceImplements().saveWrongResult(numberOfExminations, userName, inputResult);//保存错题输入
                //新建变量选择用来储存答案正确与否
                boolean choice = wrongSetService.checkInput(numberOfExminations, userName);
                if (!choice) {
                    //错误显示解析，调用WrongSetService类中的getAnnotations()函数
                    System.out.print("你答错了，题目解析如下:");
                    wrongSetService.getAnnotations(numberOfExminations, userName);
                    //解析之后进入下一题
                    numberOfExminations++;
                } else {
                    //检查输入正确，进入下一题，
                    numberOfExminations++;
                }
            }
            //如果输入h，展示解析，调用WrongSetService类中的getAnnotations()函数
            else if (input.equals("h")) {
                //展示解析
                wrongSetService.getAnnotations(numberOfExminations, userName);
                //进入下一题
                if(new WrongSetServiceImplements().checkWrongSetHasNext(userName, numberOfExminations)){
                    System.out.println("您已经完成了所有错题！快去参加考试吧！祝您满分通过！");
                    continue;
                }
                numberOfExminations++;
            }
            //输入p，numberOfExminations的值-1，重复调用调用WrongSetService类中的viewExamination()方法显示题目内容，做出选择
            else if (input.equals("p")) {
                if(numberOfExminations == 1){
                    System.out.println("当前为第一题，不能往前");
                    count = numberOfExminations;
                    continue;
                }
                numberOfExminations--;
            }
            //输入n，numberOfExminations的值+1，重复调用调用WrongSetService类中的viewExamination()方法显示题目内容，做出选择
            else if (input.equals("n")) {
                numberOfExminations++;
            }
            else if(input.equals("-")){
                new WrongSetServiceImplements().removeQuestion(userName, numberOfExminations);
                count = -1;
            }
            else if(input.equals("f")){
                return;
            }
            else {
                System.out.println("请根据提示输入规范的答案");
                count = numberOfExminations;
            }
        }while (flag);
        //输入退出循环返回ExaminationMenu界面
        choices.ShowExaminationMenu(userName);
    }
}
