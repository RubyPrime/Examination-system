package service;

import dao.Impl.QuestionDaoImplements;

public interface PracticeService {

    /**
     * 根据不同的输入，去加载不同的题库:
     *              调用QuestionDao中的createPractice()方法
     * @return null
     */
    public void loadPratice(int choice);

    /**
     * 显示测试题目：
     *           将第numberOfExaminations题的题目内容(调用QuestionDao类的getPracticeInfo方法获取题目内容),在控制台打印
     * @param numberOfExminations 第几题
     * @return null
     */
    public void viewPractice(int numberOfExminations);

    /**
     * 保存测试过程中的输入结果：
     *           根据当前的题目数调用QuestionDao中的saveResPractice(int numberOfExminations, char input)方法，保存输入
     *           再调用QuestionDao中的checkRes方法，检查输入结果，
     *              输入正确返回true，输入错误返回false,根据用户名调用UserDao类中的selectUserByName()得到用户，
     *              并调用UserDao类中的saveWrong(Question question, User user)方法保存到错题集
     * @param numberOfExminations 第几题
     * @return boolean
     */
    public boolean checkError(int numberOfExminations, String input, String userName);

    /**
     * 返回测试题目的解析：
     *           根据当前的题目调用QuestionDao中的getAnnotation()方法，得到解析内容，并打印输出解析
     * @param numberOfExminations 第几题
     * @return String
     */
    public void getAnnotations(int numberOfExminations);

    /**
     * 检查当前测试题是否还有下一题
     * @param numberOfExminations 第几题
     * @return void
     */
    public boolean chechHasNext(int numberOfExminations);
}
