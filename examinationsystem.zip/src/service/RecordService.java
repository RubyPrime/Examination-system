package service;

public interface RecordService {

    /**
     * 查看排行榜:
     *         调用RecordDao中的viewRecord()方法
     * @return null
     */
    public void viewRank();
}
