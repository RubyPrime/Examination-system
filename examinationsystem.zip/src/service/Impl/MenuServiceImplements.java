package service.Impl;

import dao.Impl.UserDaoImplements;
import pojo.User;
import service.MenuService;

import java.io.IOException;

public class MenuServiceImplements implements MenuService {
    /**
     * 登录功能流程：
     *
     *          接收从LoginView类中传入的用户名和密码
     *          根据用户名和密码操作查询用户：调用UserDao中的selectUser()函数，得到用户对象
     *          如果对象为null，代表没找到该用户，即登录失败
     *          如果对象不为null，代表找到了该用户，登录成功
     *
     * @param userName 用户名
     * @param passWord 密码
     * @return 如果返回true，表示登录成功；如果返回false，表示登录失败，跳转回主界面。
     */
    @Override
    public boolean Login(String userName, String passWord) {
        UserDaoImplements impl = new UserDaoImplements();
        try {
            if(impl.selectUser(userName, passWord)==null){
                return false;
            }else {
                new UserDaoImplements().loadUserList(); //登录成功后加载userList，便于比较时候使用
                return true;
            }
        } catch (IOException ioException) {
            System.out.println("用户文件读入异常");
            return false;
        } catch (ClassNotFoundException e) {
            System.out.println("用户文件读入异常");
            return false;
        }
    }

    /**
     * 注册功能流程：
     *          接收从控制台输入的 用户名
     *          根据用户名查询用户：调用UserDao中的selectUserByName()函数,
     *          判断返回的User对象是否为null：
     *              若为null，即未存在相同用户名，判断两次输入的密码是否一致，
     *                      若密码一致，返回true，注册成功，创建User对象，调用UserService类中的saveUser()保存对象
     *                      若密码不一致，返回false，注册失败，提示两次输入密码不能相同
     *              若不为null，返回false，存在该用户。
     * @param userName 用户名
     * @param passWord 密码
     * @param checkedPassword 第二次输入的确认密码
     * @return 如果返回true，表示注册成功；如果返回false，表示注册失败，跳转回主界面。
     */
    @Override
    public boolean Register(String userName, String passWord, String checkedPassword) {
        UserDaoImplements impl = new UserDaoImplements();
        try {
            if(userName.length() != 6){
                System.out.println("用户名长度应为6位");
                return false;
            }else if(passWord.length() < 6 || passWord.length() > 8){
                System.out.println("密码长度应在6-8位");
                return false;
            }
            if(impl.selectUserByName(userName)==null)
            {
                if(passWord.equals(checkedPassword))        //密码相同，创建用户
                {
                    UserServiceImplements x = new UserServiceImplements();
                    x.saveUser(new User(userName, passWord));       //注册成功就保存用户
//                    System.out.println("err");
                    new UserDaoImplements().updateList(userName);   //注册成功就更新userList
                    return true;
                }
                else{
                    System.out.println("两次输入密码不相同，请重新注册");
                    return false;
                }
            }
            else{
                System.out.println("已经存在该用户");
                return false;
            }
        } catch (IOException ioException) {
            System.out.println("注册系统异常，请稍后再试试吧");
            return false;
        } catch (ClassNotFoundException e) {
            System.out.println("注册系统异常，请稍后再试试吧");
            return false;
        }
    }
}
