package service.Impl;

import dao.Impl.RecordDaoImplements;
import dao.Impl.UserDaoImplements;
import pojo.User;
import service.UserService;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class UserServiceImplements implements UserService {
    /**
     * 保存考试成绩：
     *          记录输入的成绩，调用UserDao类中的saveRecord方法，保存信息.
     *          同时成绩放入排行榜，调用RecordDao中的saveRecord方法
     * @param record
     * @param userName
     * @return null
     */
    @Override
    public void saveFinalRecord(int record, String userName) {
        try {
            new UserDaoImplements().saveRecord(record, userName);
            new RecordDaoImplements().saveRecord(record, userName);
        } catch (IOException ioException) {
            System.out.println("保存成绩失败");
        } catch (ClassNotFoundException e) {
            System.out.println("保存成绩失败");
        }
    }

    /**
     * 保存用户信息到文件：
     *         将用户对象写入文件中
     * @param userSaved
     * @return null
     */
    @Override
    public void saveUser(User userSaved) throws IOException {
//        String userSavedPath = "E:\\Java项目\\examinationsystem\\user\\";   //用户对象保存的地址
        String userSavedPath = "user/";   //用户对象保存的地址

        ObjectOutputStream objectOutputStream =     //默认修改的时候覆盖,文件名为userName.txt
               new ObjectOutputStream(new FileOutputStream(userSavedPath + userSaved.getUserName() + ".txt"));
        objectOutputStream.writeObject(userSaved);
        objectOutputStream.close();
    }
}
