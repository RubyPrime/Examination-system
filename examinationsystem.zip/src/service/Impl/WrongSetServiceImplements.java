package service.Impl;

import dao.Impl.QuestionDaoImplements;
import dao.Impl.UserDaoImplements;
import dao.UserDao;
import pojo.User;
import service.WrongSetService;

import java.io.IOException;
import java.util.ArrayList;

public class WrongSetServiceImplements implements WrongSetService {
    /**
     * 显示错题题目：
     * 将第numberOfExaminations题的题目内容(调用UserDao类的getWrongSetInfo()方法获取题目内容),在控制台打印
     * @param numberOfExminations 第几题
     * @return null
     */
    @Override
    public void viewExamination (int numberOfExminations, String userName) {
        //获取题目信息
        String subject = new UserDaoImplements().getWrongSetInfo(userName, numberOfExminations);
        try {
            User user = new UserDaoImplements().selectUserByName(userName);
            ArrayList wrongSet = user.getWrongSet();
            System.out.println("当前题目" + numberOfExminations + "/" + wrongSet.size());
        } catch (IOException e) {
            System.out.println("查询用户失败");
        } catch (ClassNotFoundException e) {
            System.out.println("查询用户失败");
        }
        System.out.println("题目信息如下:");
        //打印题目
        System.out.println(subject);
    }

    /**
     * 检查错题是否做对：
     *           调用UserDao类中的checkWrongSet()方法，做对，返回true，做错了，返回false
     * @param numberOfWrongSet 第几题
     * @return boolean
     */
    @Override
    public boolean checkInput(int numberOfWrongSet, String userName) {
        //接收题目重做结果
        boolean checksubject = new UserDaoImplements().checkWrongSet(userName, numberOfWrongSet);
        //返回结果
        return checksubject;
    }

    /**
     * 打印错题解析：
     *           调用UserDao类中的getWrongSetAnnotations()方法，打印解析内容
     * @param numberOfWrongSet 第几题
     * @return null
     */
    @Override
    public void getAnnotations(int numberOfWrongSet, String userName) {
        //接收解析内容
        String analysis = new UserDaoImplements().getWrongSetAnnotations(userName ,numberOfWrongSet);
        //打印解析内容
        System.out.println(analysis);
    }

    /**
     * 保存错题的输入：
     *           调用QuestionDao类中的saveWrongRes()方法，保存错题内容
     * @param numberOfWrongSet 第几题
     * @return null
     */
    @Override
    public void saveWrongResult(int numberOfWrongSet, String userName, String input){
        new QuestionDaoImplements().saveWrongRes(numberOfWrongSet, userName, input);
    }

    /**
     * 获取错题集对象：
     *           调用UserDao类中的selectUserByName()方法，获取user对象，然后调用getWrongSet()方法，得到错题集对象
     * @param userName
     * @return null
     */
    @Override
    public boolean checkWrongSetIsNull(String userName) throws IOException, ClassNotFoundException {
        User user = new UserDaoImplements().selectUserByName(userName);
        if(user.getWrongSet() == null){
            return true;        //错题集为空
        }
        return false;
    }

    /**
     * 检查错题集是否有下一题：
     *           调用UserDao类中的selectUserByName()方法，获取user对象，然后调用getWrongSet()方法，得到错题集对象
     * @param userName
     * @return null
     */
    @Override
    public boolean checkWrongSetHasNext(String userName, int numberOfWrongSet){
        try {
            User user = new UserDaoImplements().selectUserByName(userName);
            ArrayList wrongSet = user.getWrongSet();
            wrongSet.get(numberOfWrongSet + 1);
            return true;
        } catch (IOException ioException) {
            //出现异常说明没有下一题了
            return false;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    /**
     * 删除错题：
     *          调用UserDao类中的selectUserByName()方法，获取user对象，然后调用getWrongSet()方法，得到错题集对象
     *          remove即可
     * @param userName
     * @return null
     */
    @Override
    public boolean removeQuestion(String userName, int numberOfWrongSet){
        try {
            User user = new UserDaoImplements().selectUserByName(userName);
            ArrayList wrongSet = user.getWrongSet();
            wrongSet.remove(numberOfWrongSet - 1);
            //保存对象就能保存里面的wrongSet内容
            new UserServiceImplements().saveUser(user);
            return true;
        } catch (IOException ioException) {
            System.out.println("删除错题失败");
            return false;
        } catch (ClassNotFoundException e) {
            System.out.println("删除错题失败");
            return false;
        }
    }
}
