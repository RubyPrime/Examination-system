package service.Impl;

import dao.Impl.RecordDaoImplements;
import dao.RecordDao;
import service.RecordService;

public class RecordServiceImplements implements RecordService {
    /**
     * 查看排行榜:
     *         调用RecordDao中的viewRecord()方法
     * @return null
     */
    @Override
    public void viewRank() {
        new RecordDaoImplements().viewRecord();
    }
}
