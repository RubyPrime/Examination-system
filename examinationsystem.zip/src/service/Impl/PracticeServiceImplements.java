package service.Impl;

import dao.Impl.QuestionDaoImplements;
import dao.Impl.UserDaoImplements;
import dao.QuestionDao;
import pojo.Question;
import pojo.User;
import service.PracticeService;

import java.io.IOException;

public class PracticeServiceImplements implements PracticeService {
    /**
     * 根据不同的输入，去加载不同的题库:
     *              调用QuestionDao中的createPractice()方法
     * @return null
     */
    @Override
    public void loadPratice(int choice) {
        new QuestionDaoImplements().createPractice(choice);
    }

    /**
     * 显示测试题目：
     *           将第numberOfExaminations题的题目内容(调用QuestionDao类的getPracticeInfo方法获取题目内容),在控制台打印
     * @param numberOfExminations 第几题
     * @return null
     */
    @Override
    public void viewPractice(int numberOfExminations) {
        String practiceInfo = new QuestionDaoImplements().getPracticeInfo(numberOfExminations);
        System.out.println("当前题目数为" + numberOfExminations + "/" + QuestionDao.practice.size());
        System.out.println(practiceInfo);
    }

    /**
     * 保存测试过程中的输入结果：
     *           根据当前的题目数调用QuestionDao中的saveResPractice(int numberOfExminations, char input)方法，保存输入
     *           再调用QuestionDao中的checkRes方法，检查输入结果，
     *              输入正确返回true，输入错误返回false,根据用户名调用UserDao类中的selectUserByName()得到用户，
     *              并调用UserDao类中的saveWrong(Question question, User user)方法保存到错题集
     * @param numberOfExminations 第几题
     * @return boolean
     */
    @Override
    public boolean checkError(int numberOfExminations, String input, String userName) {
        new QuestionDaoImplements().saveResPractice(numberOfExminations, input);
        boolean answer = new QuestionDaoImplements().checkRes(numberOfExminations);
        if(!answer){
            try {
                User user = new UserDaoImplements().selectUserByName(userName);
                Object o = QuestionDao.practice.get(numberOfExminations - 1);
                Question question = (Question)o;
                new UserDaoImplements().saveWrong(question, user);
            } catch (IOException ioException) {
                System.out.println("写入文件错误");
            } catch (ClassNotFoundException e) {
                System.out.println("写入文件错误");
            } finally {
                return false;
            }
        }
        //检查正确
        return true;
    }

    /**
     * 显示测试题目的解析：
     *           根据当前的题目调用QuestionDao中的getAnnotation()方法，得到解析内容，并打印输出解析
     * @param numberOfExminations 第几题
     * @return void
     */
    @Override
    public void getAnnotations(int numberOfExminations) {
        String annotation = new QuestionDaoImplements().getAnnotation(numberOfExminations);
        System.out.println("题目的解析为:" + annotation);
    }

    /**
     * 检查当前测试题是否还有下一题：
     *           查看
     * @param numberOfExminations 第几题
     * @return void
     */
    @Override
    public boolean chechHasNext(int numberOfExminations) {
        try {
            new QuestionDaoImplements().getAnnotation(numberOfExminations);
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
