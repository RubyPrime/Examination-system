package service;

public interface ExaminationService {

    /**
     * 生成考试题目：
     *           调用QuestionDao中的createExam方法，
     * @return null
    */
    public void createExamination();

    /**
     * 显示考试题目：
     *           将第numberOfExaminations题的题目内容(调用QuestionDao类的getExaminationInfo方法获取题目内容),在控制台打印
     *           将第numberOfExaminations题的你的输入(调用QuestionDao类的getExaminationInput方法获取你输入的选项),
     *           在控制台打印你的输入，便于用户查看他的之前输入的结果
     * @param numberOfExminations 第几题
     * @return null
     */
    public void viewExamination(int numberOfExminations);

    /**
     * 显示考试成绩：
     *           调用QuestionDao中的checkNumberOfCorrect方法，得到正确题目数量，返回分数。
     * @return null
     */
    public int getRecord(String userName);

    /**
     * 保存考试过程中的输入结果：
     *           根据当前的题目数调用QuestionDao中的saveRes方法，保存输入结果
     * @param numberOfExminations 第几题
     * @return null
     */
    public void saveResult(int numberOfExminations, String input);
}
