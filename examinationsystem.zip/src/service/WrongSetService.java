package service;

import java.io.IOException;

public interface WrongSetService {

    /**
     * 显示错题题目：
     *           将第numberOfExaminations题的题目内容(调用UserDao类的getWrongSetInfo()方法获取题目内容),在控制台打印
     * @param numberOfExminations 第几题
     * @return null
     */
    public void viewExamination(int numberOfExminations, String userName);

    /**
     * 检查错题是否做对：
     *           调用UserDao类中的checkWrongSet()方法，做对，返回true，做错了，返回false
     * @param numberOfWrongSet 第几题
     * @return boolean
     */
    public boolean checkInput(int numberOfWrongSet, String userName);

    /**
     * 打印错题解析：
     *           调用UserDao类中的getWrongSetAnnotations()方法，打印解析内容
     * @param numberOfWrongSet 第几题
     * @return null
     */
    public void getAnnotations(int numberOfWrongSet, String userName);

    /**
     * 保存错题的输入：
     *           调用QuestionDao类中的saveWrongRes()方法，保存错题内容
     * @param numberOfWrongSet 第几题
     * @return null
     */
    public void saveWrongResult(int numberOfWrongSet, String userName, String input);

    /**
     * 检查错题集是否为null：
     *           调用UserDao类中的selectUserByName()方法，获取user对象，然后调用getWrongSet()方法，得到错题集对象
     * @param userName
     * @return null
     */
    public boolean checkWrongSetIsNull(String userName) throws IOException, ClassNotFoundException;

    /**
     * 检查错题集是否有下一题：
     *           调用UserDao类中的selectUserByName()方法，获取user对象，然后调用getWrongSet()方法，得到错题集对象
     *           ，用
     * @param userName
     * @return null
     */
    public boolean checkWrongSetHasNext(String userName, int numberOfWrongSet);

    /**
     * 删除错题：
     *          调用UserDao类中的selectUserByName()方法，获取user对象，然后调用getWrongSet()方法，得到错题集对象
     *          remove即可
     * @param userName
     * @return null
     */
    public boolean removeQuestion(String userName, int numberOfWrongSet) throws IOException, ClassNotFoundException;
}
