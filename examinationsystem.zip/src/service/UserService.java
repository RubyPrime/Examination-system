package service;

import pojo.User;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface UserService {
    /**
     * 保存考试成绩：
     *          记录输入的成绩，调用UserDao中的selectUserByName方法，根据找到的User对象，调用UserDao类中的saveRecord方法，保存信息.
     *          调用UserService类中的saveUser()方法保存对象
     *          成绩放入排行榜，调用RecordDao中的saveRecord方法
     * @param record
     * @param userName
     * @return null
     */
    public void saveFinalRecord(int record,String userName);

    /**
     * 保存用户信息到文件：
     *         将用户对象写入文件中
     * @param userSaved
     * @return null
     */
    public void saveUser(User userSaved) throws IOException;
}
