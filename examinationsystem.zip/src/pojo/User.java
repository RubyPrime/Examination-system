package pojo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class User implements Serializable {
    private String userName;//用户名
    private String passWord;//密码
    private ArrayList record = null;       //维护一个String数组记录历史成绩及其相关信息
    private ArrayList wrongSet = null;       //维护一个wrongSet记录错题，存放Question对象

    public User(String userName, String passWord) {
        this.userName = userName;
        this.passWord = passWord;
    }

    public void addRecord(String record) {
        if(this.record == null){
            this.record = new ArrayList();  //为空就创建
        }
        this.record.add(record);
    }

    public ArrayList getWrongSet() {
        return wrongSet;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public ArrayList getRecord() {
        return record;
    }

    public void addtWrongSet(Question question){
        if(wrongSet == null){
            wrongSet = new ArrayList();
        }
        wrongSet.add(question);
    }
}
