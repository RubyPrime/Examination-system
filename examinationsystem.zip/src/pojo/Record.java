package pojo;

import java.io.Serializable;

public class Record implements Serializable {
    private String userName;        //用户名
    private int record;          //分数
    private String time;            //日期，格式为："yyyy-MM-dd HH:mm:ss"

    public Record(String userName, int record, String time) {
        this.userName = userName;
        this.record = record;
        this.time = time;
    }

    public int getRecord() {
        return record;
    }

    public String getTime() {
        return time;
    }

    @Override
    public String toString() {
        return "{用户名='" + userName + '\'' +
                ", 分数=" + record +
                ", 日期='" + time + '\'' +
                '}';
    }
}
