package pojo;

import java.io.Serializable;

public class Question implements Serializable {
    private String info;        //题目信息
    private String answer;        //题目结果
    private String analysis;        //题目解析
    private String input = "";         //题目输入的结果，只有考试的时候需要，对于判断题,0错误，1正确

    public Question(String info, String answer, String analysis) {
        this.info = info;
        this.answer = answer;
        this.analysis = analysis;
    }

    public String getInfo() {
        return info;
    }

    public String getAnswer() {
        return answer;
    }

    public String getAnalysis() {
        return analysis;
    }

    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }

    @Override
    public String toString() {
        return "Question{" +
                "info='" + info + '\'' +
                '}';
    }
}
