package updateexercise;

import pojo.Question;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

//import static sun.security.util.Debug.args;

/**
 * @ClassName:ReadExerciseTest
 * @Auther: uruom
 * @Description: 检测一下是不是正常保存
 * @Date: 2022/8/18 13:11
 * @Version: v1.0
 */
public class ReadExerciseTest {
    static ArrayList<Question> questions = new ArrayList<>();
    public static void main() throws IOException, ClassNotFoundException {
        System.out.println("请输入想要测试的题目序号X，X为数字");
        System.out.println("请输入X：");
        Scanner scanner = new Scanner(System.in);
        int numberofExercise = scanner.nextInt();
//        读入需要验证的题号

        ObjectInputStream oisnumber =
                new ObjectInputStream(new FileInputStream("exercise/exercise"+String.valueOf(numberofExercise)+"/numberofqusetion.txt"));
        int number = (int) oisnumber.readObject();

//        读入总的题目数
        for (int i = 1; i <= number; i++) {
//            writeQuestion(readQuestion("exercise/exercise"+String.valueOf(numberofExercise)+"/question"+String.valueOf(i)+".txt"));
            addQuestion(readQuestion("exercise/exercise"+String.valueOf(numberofExercise)+"/question"+String.valueOf(i)+".txt"));

        }
    }

//    读入题目，以Questino的方式
    private static Question readQuestion(String filename) throws IOException, ClassNotFoundException {
        ObjectInputStream oisQuestion =
                new ObjectInputStream(new FileInputStream(filename));
        Question question = (Question) oisQuestion.readObject();
        oisQuestion.close();
        return question;
    }
//  输出题目，验证Question是否保存
    private static void writeQuestion(Question question){
        System.out.println(question.getInfo());
        System.out.println(question.getAnswer());
        System.out.println(question.getInput());
        System.out.println(question.getAnalysis());
        System.out.println("===================================================================");

    }
    private static void addQuestion(Question question){
        questions.add(question);
    }
    public ArrayList<Question> getQuestion() throws IOException, ClassNotFoundException {
        main();
        return questions;
    }

}
