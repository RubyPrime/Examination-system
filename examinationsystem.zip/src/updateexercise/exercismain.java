package updateexercise;

import pojo.Question;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @ClassName:exercismain
 * @Auther: uruom
 * @Description: 生成题库组
 * @Date: 2022/8/18 11:42
 * @Version: v1.0
 */
public class exercismain {
    public static void main(String args[]) throws IOException {
        System.out.println("请输入想要转换的题目编号，题目请放在exercise文件夹下");
        System.out.println("命名格式为answerX，exerciseX,其中X为数字，请确保题目与题目，答案与答案间为一个回车分割");
        System.out.println("请输入X：");
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
//        读入题目编号，然后将里面的题目自动封装成一个个的小题目

        File fileExercise = new File("exercise/exercise"+String.valueOf(number)+".txt");
        Scanner scExercise = new Scanner(fileExercise);
        File fileAnswer = new File("exercise/answer"+String.valueOf(number)+".txt");
        Scanner scAnswer = new Scanner(fileAnswer);
        creaateFile("exercise/exercise"+number);

//        生成exerciseX的文件夹，打开两个文件

        String questionInfo="",tempQuestionInfo="";
        int questionNumber=0;

//        初始化
        while(scExercise.hasNextLine()){
            tempQuestionInfo = scExercise.nextLine();
//            因为Qusetion中没有分段，所有的题目只有一个字符串，所以我是把所有选项拼接起来了，如果要换行的话，那要改下Question
            questionInfo=questionInfo+tempQuestionInfo;
//            判断，如果读到了回车，证明下一题，输出当前题目
            if (tempQuestionInfo.equals("")) {
                questionNumber++;
                Question question = new Question(questionInfo,scAnswer.nextLine(),"");
//                生成question
                questionInfo = "";
//                初始化，
                saveField("exercise/exercise"+number+"/question"+String.valueOf(questionNumber)+".txt",question);
//                将question输出
            }
        }
//        输出questino数目
        saveField("exercise/exercise"+number+"/numberofqusetion.txt",questionNumber-1);


    }
//    数据保存函数
    private static void saveField(String fieldName, Object fieldValue) throws IOException, IOException {

        FileOutputStream fos = new FileOutputStream(new File(fieldName));

        ObjectOutputStream oos = new ObjectOutputStream(fos);

        oos.writeObject(fieldValue);

        oos.close();

    }
//    创建文件夹函数
    private  static void creaateFile(String filename) throws IOException {
        Path path = Paths.get(filename);
        Files.createDirectories(path);
    }
}
