package dao;

import pojo.Question;
import pojo.User;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface UserDao {

    /**io
     * 根据用户名和密码操作查询用户,用户名和密码都能对上，则返回对象，否则返回null
     * @param userName 用户名
     * @param passWord 密码
     * @return User 返回用户对象。
     */
    public User selectUser(String userName, String passWord) throws IOException, ClassNotFoundException;


    /**io
     * 根据用户名操作查询用户,有相同的用户名即返回改User对象，否则返回null
     * @param userName 用户名
     * @return User 返回用户对象。
     */
    public User selectUserByName(String userName) throws IOException, ClassNotFoundException;

    /**
     * 保存考试成绩：记录输入的成绩，调用UserDao类中的selectUserByName方法查询用户，
     * 调用User类中的setRecord方法，保存信息,信息是用户名+获取本地时间+分数进行拼接，然后保存用户，调用UserService下面的saveUser方法
     * @param record
     * @param userName
     * @return null
     */
    public void saveRecord(int record,String userName) throws IOException, ClassNotFoundException;

    /**arrayList
     * 保存错题
     *          调用User类中的getWrongSet()方法，获取错题集list，然后保存Question对象。
     * @param question
     * @return null
     */
    public void saveWrong(Question question, User user) throws IOException;

    /**
     * 获取错题集信息，
     *          调用UserDao类中的selectUserByName()方法，获取User对象，调用User对象的getWrongSet()方法，获取错题集。
     *          返回错题集的第numberOfExminations个内容
     * @param userName
     * @param numberOfExminations
     * @return String
     */
    public String getWrongSetInfo(String userName, int numberOfExminations);

    /**
     * 检查错题集的重做结果是否正确，
     *          调用UserDao类中的selectUserByName()方法，获取User对象，调用User对象的getWrongSet()方法，获取错题集对象。
     *          输出错题集的第numberOfExminations个question对象的getAnswer()和getInfo()方法，判断是否正确结果和输入是否相同
     *          若相同，返回true，不同，返回false
     * @param userName
     * @param numberOfExminations
     * @return boolean
     */
    public boolean checkWrongSet(String userName, int numberOfExminations);

    /**
     * 检查错题集的重做结果是否正确，
     *          调用UserDao类中的selectUserByName()方法，获取User对象，调用User对象的getWrongSet()方法，获取错题集对象。
     *          输出错题集的第numberOfExminations个question对象的getAnalysis()方法，返回String解析内容
     * @param userName
     * @param numberOfExminations
     * @return String
     */
    public String getWrongSetAnnotations(String userName, int numberOfExminations);
}
