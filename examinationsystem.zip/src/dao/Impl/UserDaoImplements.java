package dao.Impl;

import dao.UserDao;
import pojo.Question;
import pojo.User;
import service.Impl.UserServiceImplements;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

public class UserDaoImplements implements UserDao {
    private UserListClass userListClass = null;

    public void loadUserList() throws IOException, ClassNotFoundException { //加载userList，存放用户名的地方
//        ObjectInputStream oisuserList =
//                new ObjectInputStream(new FileInputStream("E:\\Java项目\\examinationsystem\\user\\namelist.txt"));
        ObjectInputStream oisuserList =
                new ObjectInputStream(new FileInputStream("user/namelist.txt"));
        userListClass = (UserListClass) oisuserList.readObject();
        oisuserList.close();
//        System.out.println("Success load");
    }

    public void updateList(String userName) throws IOException, ClassNotFoundException {        //更新userList
        try {
            loadUserList();     //先加载对象
        } catch (IOException ioException) {
            userListClass = new UserListClass();    //第一次加载时创建一个对象
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
//        ObjectOutputStream oos =        //对象一直只有一个，不需要追加保存
//                new ObjectOutputStream(new FileOutputStream("E:\\Java项目\\examinationsystem\\user\\namelist.txt"));
        ObjectOutputStream oos =        //对象一直只有一个，不需要追加保存
                new ObjectOutputStream(new FileOutputStream("user/namelist.txt"));
        userListClass.addUser(userName);
        oos.writeObject(userListClass);
        oos.close();
    }

    /**
     * 根据用户名和密码操作查询用户,用户名和密码都能对上，则返回对象，否则返回null
     * @param userName 用户名
     * @param passWord 密码
     * @return User 返回用户对象。
     */
    @Override
    public User selectUser(String userName, String passWord) throws IOException, ClassNotFoundException {
        User user=selectUserByName(userName);
        if (user==null) {
            return null;
        }else{
            if (user.getPassWord().equals(passWord)) {
                return user;
            }else {
                return null;
            }
        }
    }

    /**
     * 根据用户名操作查询用户,有相同的用户名即返回改User对象，否则返回null
     * @param userName 用户名
     * @return User 返回用户对象。
     */
    @Override
    public User selectUserByName(String userName) throws IOException, ClassNotFoundException {
        try {       //加载的时候看是否遇到异常
            loadUserList();
        } catch (IOException ioException) { //如果找不到，就说明还没有用户
            return null;
        } catch (ClassNotFoundException e) {
            return null;
        }
        //        判断在名单中是否有这个user，如果有则加载User类，读取返回，否则，返回空
        if (userListClass.compare(userName)) {
            ObjectInputStream oisuser =
//                    new ObjectInputStream(new FileInputStream("E:\\Java项目\\examinationsystem\\user\\"+userName+".txt"));
            new ObjectInputStream(new FileInputStream("user/"+userName+".txt"));
            return (User) oisuser.readObject();
        }else{
            return null;
        }
    }

    /**
     * 保存考试成绩：记录输入的成绩，调用UserDao类中的selectUserByName方法查询用户，
     * 调用User类中的setRecord方法，保存信息,信息是用户名+获取本地时间+分数进行拼接，然后保存用户，调用UserService下面的saveUser方法
     * @param record
     * @param userName
     * @return null
     */
    @Override
    public void saveRecord(int record, String userName) throws IOException, ClassNotFoundException {
        User user = selectUserByName(userName);
        if (user==null) {
            System.out.println("用户名错误，无法保存");
        }else{
//            用户名+获取本地时间+分数进行拼接
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            user.addRecord("用户" + userName + ":" + LocalDateTime.now().format(formatter) + "考到了" + record + "分");
            new UserServiceImplements().saveUser(user);
        }
    }

    /**
     * 保存错题
     *          调用User类中的getWrongSet()方法，获取错题集list，然后保存Question对象。
     * @param question
     * @return null
     */
    @Override
    public void saveWrong(Question question, User user) throws IOException {
        user.addtWrongSet(question);
        new UserServiceImplements().saveUser(user); //写入用户
    }

    /**
     * 获取错题集信息，
     *          调用UserDao类中的selectUserByName()方法，获取User对象，调用User对象的getWrongSet()方法，获取错题集。
     *          返回错题集的第numberOfExminations个内容
     * @param userName
     * @param numberOfExminations
     * @return String
     */
    @Override
    public String getWrongSetInfo(String userName, int numberOfExminations) {
        try {
            User user = selectUserByName(userName);
            ArrayList x = user.getWrongSet();
            //获取错题里面存放的错题对象
            Object y = x.get(numberOfExminations - 1);
            //错题
            Question z = (Question)y;
            return z.getInfo();
        } catch (IOException ioException) {
            System.out.println("用户查询异常");
            return null;
        } catch (ClassNotFoundException e) {
            System.out.println("用户查询异常");
            return null;
        }
    }

    /**
     * 检查错题集的重做结果是否正确，
     *          调用UserDao类中的selectUserByName()方法，获取User对象，调用User对象的getWrongSet()方法，获取错题集对象。
     *          调用错题集的第numberOfExminations个question对象的getAnswer()和getInfo()方法，判断是否正确结果和输入是否相同
     *          若相同，返回true，不同，返回false
     * @param userName
     * @param numberOfExminations
     * @return boolean
     */
    @Override
    public boolean checkWrongSet(String userName, int numberOfExminations) {
        try {
            User user = selectUserByName(userName);
            ArrayList x = user.getWrongSet();
            Object y = x.get(numberOfExminations - 1);
            Question z = (Question)y;
            if (z.getAnswer().equals(z.getInput())){
                return true;
            }
            else {
                return false;
            }
        } catch (IOException ioException) {
            System.out.println("用户查询异常");
            return false;
        } catch (ClassNotFoundException e) {
            System.out.println("用户查询异常");
            return false;
        }
    }

    /**
     * 检查错题集的重做结果是否正确，
     *          调用UserDao类中的selectUserByName()方法，获取User对象，调用User对象的getWrongSet()方法，获取错题集对象。
     *          调用错题集的第numberOfExminations个question对象的getAnalysis()方法，返回String解析内容
     * @param userName
     * @param numberOfExminations
     * @return String
     */
    @Override
    public String getWrongSetAnnotations(String userName, int numberOfExminations) {
        try {
            User user = selectUserByName(userName);
            ArrayList x = user.getWrongSet();
            Object y = x.get(numberOfExminations - 1);
            Question z = (Question)y;
            return z.getAnalysis();
        } catch (IOException ioException) {
            System.out.println("用户查询异常");
            return null;
        } catch (ClassNotFoundException e) {
            System.out.println("用户查询异常");
            return null;
        }
    }
}
