package dao.Impl;

import pojo.Question;
import updateexercise.ReadExerciseTest;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;


/** 这个输出没有清空，后续要改的话要改一下，不然没法检验和更改，每次都是叠加记录到上一个的下面，我找了半天emmm，下次要调用这个函数之前，先把对应的txt文件中的内容先删了，不然根本没有
*
 */
public class EditorExamination {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
//        FileOutputStream out = new FileOutputStream("E:\\Java项目\\examinationsystem\\test\\1.txt", true);
        ReadExerciseTest readExerciseTest = new ReadExerciseTest();
        ArrayList<Question> questions = readExerciseTest.getQuestion();
//        System.out.println("aaaaa");
        FileOutputStream out = new FileOutputStream("test/1.txt", true);
        ObjectOutputStream oos = new ObjectOutputStream(out);
        HashMap<Integer, Question> qs = new HashMap<Integer,Question>();
        /*******输入*******/
        Scanner inputInfo = new Scanner(System.in);
        Scanner inputAnswer = new Scanner(System.in);
        Scanner inputAnalysis = new Scanner(System.in);
        for(int i = 0; i < 100; i++){
//            qs.put(i + 1,new Question("a"+i, "A", i + "ad" + i));
            qs.put(i + 1, questions.get(i%12+1));
        }
        oos.writeObject(qs);
        oos.close();
    }
}
