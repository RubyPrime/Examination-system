package dao.Impl;

import pojo.Question;
import updateexercise.ReadExerciseTest;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class EditorPractice {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
//        FileOutputStream out = new FileOutputStream("E:\\Java项目\\examinationsystem\\practice\\4.txt", true);
        FileOutputStream out = new FileOutputStream("practice/4.txt", true);
        ReadExerciseTest readExerciseTest = new ReadExerciseTest();

        ArrayList<Question> questions = readExerciseTest.getQuestion();
        ObjectOutputStream oos = new ObjectOutputStream(out);
        HashMap<Integer, Question> qs = new HashMap<Integer,Question>();
        /*******输入*******/
        Scanner inputInfo = new Scanner(System.in);
        Scanner inputAnswer = new Scanner(System.in);
        Scanner inputAnalysis = new Scanner(System.in);
        for(int i = 0; i < 100; i++){
//            qs.put(i + 1,new Question("a"+i, "A", i + "ad" + i));
            qs.put(i + 1, questions.get(i%12+1));

        }
        oos.writeObject(qs);
        oos.close();
    }
}
