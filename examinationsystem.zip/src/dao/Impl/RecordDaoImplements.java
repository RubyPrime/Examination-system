package dao.Impl;

import dao.RecordDao;
import pojo.Record;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class RecordDaoImplements implements RecordDao {
    /**
     * 保存排行榜：
     *      读取record数组，调用RecordDao类中的readRecord()方法，
     *      创建一个record对象，在放入record数组的时候调用RecordDao类中的compare方法，实现放入的元素是有序的并且只显示前10个.
     *      最后调用RecordDao类中的writeRecord()方法，将record数组写入文件中保存
     * @return void
     */
    @Override
    public void saveRecord(int record, String userName) {
        try {
            readRecord();
        } catch (IOException ioException) {
            try {
                writeRecord();
            } catch (IOException e) {
                System.out.println("创建排行榜异常");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("读取排行榜异常");
            return;
        }
        int realLength = 0; //排行榜的真实长度
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        //创建Record对象
        Record record1 = new Record(userName, record, LocalDateTime.now().format(formatter));
        for(Record eachRecord: RecordDao.record){
            if(eachRecord != null){
                realLength++;
            }
        }
        Record[] recordsNew = new Record[realLength + 1];
        //长度过大，传入新的数组进入比较
        if(realLength == 10){
            //长度过大，只需复制10个，此时需要recordNew长为11
            System.arraycopy(RecordDao.record, 0, recordsNew, 0, realLength);
            recordsNew[realLength] = record1;
            compare(recordsNew, userName);
            for (int i = 0; i < realLength; i++) {
                RecordDao.record[i] = recordsNew[i];
            }
        }else if(realLength == 0){
            //添加排行榜元素
            RecordDao.record[realLength] = record1;
        }else {
            //添加排行榜元素
            RecordDao.record[realLength] = record1;
            //长度不够10个，需要复制全部元素
            realLength++;
            System.arraycopy(RecordDao.record, 0, recordsNew, 0, realLength);
            compare(recordsNew, userName);
            for (int i = 0; i < realLength; i++) {
                if(recordsNew[i] == null){
                    break;
                }
                RecordDao.record[i] = recordsNew[i];
            }
        }
        try {
            writeRecord();
        } catch (IOException ioException) {
            System.out.println("保存排行榜失败");
        }
    }

    /**
     * 实现放入的元素是有序(按分数从大到小)的并且只显示前10个:
     *              实现Comparator接口的匿名实现类，自定义排序方法(分数大在前面，分数相同日期小在前面)，然后只保存前10个元素
     */
    @Override
    public void compare(Record[] records, String userName) {
        Arrays.sort(records, new Comparator<Record>() {
            @Override
            public int compare(Record o1, Record o2) {
                if(o1.getRecord() != o2.getRecord()){
                    return (o2.getRecord() - o1.getRecord());
                }else{
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                    LocalDateTime parse1 = LocalDateTime.parse(o1.getTime(), formatter);
                    LocalDateTime parse2 = LocalDateTime.parse(o2.getTime(), formatter);
                    if(parse1.isBefore(parse2)){
                        return -1;
                    }else {
                        return 1;
                    }
                }
            }
        });
    }

    /**
     * 在控制台上打印record数组
     */
    @Override
    public void viewRecord() {
        try {
            readRecord();
        } catch (IOException ioException) {
            System.out.println("读取排行榜异常");
            return;
        } catch (ClassNotFoundException e) {
            System.out.println("读取排行榜异常");
            return;
        }
        System.out.println ("===排行榜===");
        for (int i = 0; i < 10; i++) {
            if(RecordDao.record[i] == null){
                break;
            }
            System.out.println(RecordDao.record[i]);
        }
    }

    /**
     * 将record数组写回到文件中保存
     */
    @Override
    public void writeRecord() throws IOException {
        //字节流输出
//        FileOutputStream fos = new FileOutputStream("E:\\Java项目\\examinationsystem\\record\\record.txt");
        FileOutputStream fos = new FileOutputStream("record/record.txt");

        //创建序列化对象
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        //保存对象到文件里
        oos.writeObject(record);
    }

    /**
     * 从文件中读取排行榜数组，保存到上面的record数组中
     */
    @Override
    public void readRecord() throws IOException, ClassNotFoundException {
//        FileInputStream fis = new FileInputStream("E:\\Java项目\\examinationsystem\\record\\record.txt");
        FileInputStream fis = new FileInputStream("record/record.txt");

        ObjectInputStream ois = new ObjectInputStream(fis);
        //存入record对象中
        Object get = ois.readObject();
        Record[] records = (Record[])get;
        //复制到record数组中
        for (int i = 0; i < 10; i++) {
            record[i] = records[i];
        }
    }
}
