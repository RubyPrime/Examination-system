package dao.Impl;

import dao.QuestionDao;
import dao.UserDao;
import pojo.Question;
import pojo.User;
import service.Impl.UserServiceImplements;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class QuestionDaoImplements implements QuestionDao {
    /**
     * 生成题目：
     *        加载100个Question对象到数组中，总共100题,考试是一次性的，用数组保存考题即可
     * @return null
     */
    @Override
    public void createExam() {
//        String examinationPath = "E:\\Java项目\\examinationsystem\\test\\1.txt";//考试题路径
        String examinationPath = "test/1.txt";//考试题路径

        ObjectInputStream readExamination = null;
//        System.out.println("AAAAA|||||A");

        try {
            readExamination = new ObjectInputStream(new FileInputStream(examinationPath));
            HashMap<Integer,Question> questions = (HashMap<Integer,Question>)readExamination.readObject();
            Iterator<Integer> iterator = questions.keySet().iterator();
            while (iterator.hasNext()){
                int key = iterator.next();
//                System.out.println(questions.get(key).getInfo());
                QuestionDao.examinations[key - 1] = (Question)questions.get(key);
//                System.out.println(QuestionDao.examinations[key - 1].getInfo());

//                System.out.println(key);
//                System.out.println(QuestionDao.examinations[key - 1].getInfo());

            }
        } catch (IOException | ClassNotFoundException ioException) {
            ioException.printStackTrace();
        } finally {
            try {
                readExamination.close();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
    }

    /**
     * 显示题目：
     *          根据传入的题目号，在数组中查找对象，调用Question类中的getInfo()方法，getInfo()返回题目信息
     * @param numberOfExminations 第几题
     * @return String
     */
    @Override
    public String getExaminationInfo(int numberOfExminations) { return examinations[numberOfExminations-1].getInfo(); }

    /**
     * 显示题目你的输入：
     *          根据传入的题目号，在数组中查找对象，调用Question类中的getInput()返回当前输入的结果，getInfo()返回题目信息
     * @param numberOfExminations 第几题
     * @return String
     */
    @Override
    public String getExaminationInput(int numberOfExminations) { return examinations[numberOfExminations-1].getInput(); }

    /**
     * 得到正确的题目的数量：
     *              根据上面的examinations数组，遍历，调用QuestionDao类中的checkExaminations(int numberOfExminations)方法，
     *              根据返回结果，如果为true，正确题目数量+1，否则不变
     *              返回累计的正确的题目数量
     * @return int
     */
    @Override
    public int checkNumberOfCorrect(String userName) {
        //变量sum用于记录正确题目数量
        int sum = 0;
        for(int i=0;i< examinations.length;i++){
            //用if语句判断对应题目号的题目是否回答正确，如果正确sum加一
            if(checkExaminations(i+1, userName)){
                sum++;
            }
        }
        return sum;
    }

    /**
     * 判断考试题题是否答对：
     *              根据输入题目号numberOfExminations，去数组找Question对象，通过调用Question对象的getAnswer和getInput方法，比较结果是否相同
     *              若为true，结果相同
     *              若为flase，结果不同，根据userName查找user，
     *                      调用UserDao类中的saveWrong(Question question, User user)方法保存到错题集
     * @return boolean
     */
    @Override
    public boolean checkExaminations(int numberOfExminations, String userName) {
        if(examinations[numberOfExminations - 1].getInput().equals(examinations[numberOfExminations - 1].getAnswer())){
            return true;
        }else {
            //保存错题
            User user = null;
            try {
                user = new UserDaoImplements().selectUserByName(userName);
            } catch (IOException ioException) {
                System.out.println("用户文件读取异常，错题加载失败");
                return false;
            } catch (ClassNotFoundException e) {
                System.out.println("用户文件读取异常，错题加载失败");
                return false;
            }
            try {
                new UserDaoImplements().saveWrong(examinations[numberOfExminations - 1], user);
            } catch (IOException ioException) {
                System.out.println("错题保存失败");
                return false;
            }
            return false;
        }
    }

    /**
     * 生成测试题：
     *         根据不同的题库，即choice，去加载Question对象到practice中。
     * @param choice
     * @return null
     */
    @Override
    public void createPractice(int choice) {
        String examinationRealPath = "practice/";
//
        examinationRealPath = examinationRealPath + choice + ".txt";
        ObjectInputStream readExamination = null;
        try {
            readExamination = new ObjectInputStream(new FileInputStream(examinationRealPath));
            Object getExamination = readExamination.readObject();
            if(!(getExamination instanceof HashMap)){
                System.out.println("读入错误的数据,题库生成失败");
                return;
            }
            HashMap questions = (HashMap)getExamination;
            Iterator<Integer> iterator = questions.keySet().iterator();
            while (iterator.hasNext()){
                int key = iterator.next();
                QuestionDao.practice.add(questions.get(key));
            }
        } catch (IOException | ClassNotFoundException ioException) {
            System.out.println("测试题加载失败");
        } finally {
            try {
                readExamination.close();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
    }

    /**
     * 显示测试题目：
     *          根据传入的题目号，在arrayList中查找对象，返回题目信息,调用Question对象的getInfo()方法返回题目信息
     * @param numberOfExminations 第几题
     * @return String
     */
    @Override
    public String getPracticeInfo(int numberOfExminations) {
        Object object = practice.get(numberOfExminations - 1);  //获取到的question对象
        Question question = null;
        if(object instanceof Question){
            question = (Question)object;
        }else {
            System.out.println("题库出现问题");
            return null;
        }
        return question.getInfo();
    }

    /**
     * 保存考试题目的输入结果：
     * 根据输入题目号numberOfExminations，去数组找Question对象，通过调用Question对象的setInput方法，保存输入的结果
     *
     * @param numberOfExminations
     * @param input
     * @return null
     */
    @Override
    public void saveRes(int numberOfExminations, String input) { examinations[numberOfExminations - 1].setInput(input); }

    /**
     * 检查测试题的输入和正确结果是否匹配：
     * 根据输入题目号numberOfExminations，去ArrayList找Question对象，通过调用Question对象的getAnswer()方法，判断输入和结果是否相同
     * 相同，返回true
     * 不同，返回false,
     *
     * @param numberOfExminations
     * @return boolean
     */
    @Override
    public boolean checkRes(int numberOfExminations) {
        Object o = practice.get(numberOfExminations - 1);
        Question question = (Question)o;
        if(question.getInput().equals(question.getAnswer())){
            return true;
        }else {
            return false;
        }
    }

    /**
     * 得到测试题的注释：
     * 根据输入题目号numberOfExminations，去pojo找Question对象，通过调用Question对象的getAnalysis()方法，返回解析内容
     *
     * @return String
     */
    @Override
    public String getAnnotation(int numberOfExminations) {
        Object get = practice.get(numberOfExminations - 1);
        if(get instanceof Question){
            Question question = (Question)get;
            return question.getAnalysis();
        }
        return "解析错误";
    }

    /**
     * 保存测试题目的输入结果：
     *              根据输入题目号numberOfExminations，去找practice，通过调用Question对象的setInput方法，保存输入的结果
     * @param numberOfExminations
     * @param input
     * @return null
     */
    @Override
    public void saveResPractice(int numberOfExminations, String input) {
        Object o = practice.get(numberOfExminations - 1);
        Question question = (Question)o;
        question.setInput(input);
    }

    /**
     * 保存错题的输入结果：
     * 根据输入题目号numberOfExminations，去数组找Question对象，通过调用Question对象的setInput方法，保存输入的结果
     *
     * @param numberOfExminations
     * @param input
     * @return null
     */
    @Override
    public void saveWrongRes(int numberOfExminations, String userName, String input) {
        try {
            User user = new UserDaoImplements().selectUserByName(userName);
            ArrayList wrongSet = user.getWrongSet();
            Object o = wrongSet.get(numberOfExminations - 1);
            Question question = (Question)o;
            question.setInput(input);
            //需要及时保存用户信息
            new UserServiceImplements().saveUser(user);
        } catch (IOException ioException) {
            System.out.println("保存输入结果失败");
        } catch (ClassNotFoundException e) {
            System.out.println("保存输入结果失败");
        }
    }
}
