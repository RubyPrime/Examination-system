package dao.Impl;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @ClassName:NameListClass
 * @Auther: uruom
 * @Description: 记录所有User名单
 * @Date: 2022/8/14 20:55
 * @Version: v1.0
 */
public class UserListClass implements Serializable {
    private ArrayList<String> arrayList = new ArrayList<String>();
    public void addUser(String userName){
        arrayList.add(userName);
    }
    public Boolean compare(String userName){
        for (String string :arrayList){
            if (userName.equals(string)) {
                return true;
            }
        }
        return false;
    }
}
