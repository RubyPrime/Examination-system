package dao;

import pojo.Question;

import java.util.ArrayList;

public interface QuestionDao {
    Question[] examinations = new Question[55];    //定义一个长为100的Question数组，
    ArrayList practice = new ArrayList();     //用practice保存测试题目，为了避免不知道长度，方便添加

    /**IO
     * 生成题目：
     *        加载100个Question对象到数组中，总共100题,考试是一次性的，用数组保存考题即可
     * @return null
     */
    public void createExam();

    /**
     * 显示题目：
     *          根据传入的题目号，在数组中查找对象，调用Question类中的getInfo()方法，getInfo()返回题目信息
     * @param numberOfExminations 第几题
     * @return String
     */
    public String getExaminationInfo(int numberOfExminations);

    /**
     * 显示题目你的输入：
     *          根据传入的题目号，在数组中查找对象，调用Question类中的getInput()返回当前输入的结果，getInfo()返回题目信息
     * @param numberOfExminations 第几题
     * @return String
     */
    public String getExaminationInput(int numberOfExminations);

    /**
     * 得到正确的题目的数量：
     *              根据上面的examinations数组，遍历，调用QuestionDao类中的checkExaminations(int numberOfExminations)方法，
     *              根据返回结果，如果为true，正确题目数量+1，否则不变
     *              返回累计的正确的题目数量
     * @return int
     */
    public int checkNumberOfCorrect(String userName);

    /**
     * 判断考试题题是否答对：
     *              根据输入题目号numberOfExminations，去数组找Question对象，通过调用Question对象的getAnswer和getInput方法，比较结果是否相同
     *              若为true，结果相同
     *              若为flase，结果不同，调用UserDao类中的saveWrong(Question question)方法保存到错题集
     * @return boolean
     */
    public boolean checkExaminations(int numberOfExminations, String userName);

    /**IO
     * 生成测试题：
     *         根据不同的题库，即choice，去加载Question对象到practice中。
     * @param choice
     * @return null
     */
    public void createPractice(int choice);

    /**
     * 显示测试题目：
     *          根据传入的题目号，在arrayList中查找对象，返回题目信息,调用Question对象的getInfo()方法返回题目信息
     * @param numberOfExminations 第几题
     * @return String
     */
    public String getPracticeInfo(int numberOfExminations);

    /**
     * 保存考试题目的输入结果：
     *              根据输入题目号numberOfExminations，去数组找Question对象，通过调用Question对象的setInput方法，保存输入的结果
     * @param numberOfExminations
     * @param input
     * @return null
     */
    public void saveRes(int numberOfExminations, String input);

    /**
     * 检查测试题的输入和正确结果是否匹配：
     *       根据输入题目号numberOfExminations，去ArrayList找Question对象，通过调用Question对象的getAnswer()方法，判断输入和结果是否相同
     *            相同，返回true
     *            不同，返回false,
     * @param numberOfExminations
     * @return boolean
     */
    public boolean checkRes(int numberOfExminations);

    /**
     * 得到测试题的注释：
     *          根据输入题目号numberOfExminations，去practice找Question对象，通过调用Question对象的getAnalysis()方法，返回解析内容
     * @return String
     */
    public String getAnnotation(int numberOfExminations);

    /**
     * 保存测试题目的输入结果：
     *              根据输入题目号numberOfExminations，去数组找Question对象，通过调用Question对象的setInput方法，保存输入的结果
     * @param numberOfExminations
     * @param input
     * @return null
     */
    public void saveResPractice(int numberOfExminations, String input);

    /**
     * 保存错题的输入结果：
     *   根据userName，去找user对象，然后将对象的错题集属性，根据numberOfExminations去找Question对象，保存input到Question对象中
     *
     * @param numberOfExminations
     * @param userName
     * @param input
     * @return null
     */
    public void saveWrongRes(int numberOfExminations, String userName, String input);
}
