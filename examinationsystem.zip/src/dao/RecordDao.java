package dao;

import pojo.Record;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface RecordDao {
    Record[] record = new Record[10];     //排行榜长度为10，不显示更多排名
    /**
     * 保存排行榜：
     *      读取record数组，调用RecordDao类中的readRecord()方法，
     *      创建一个record对象，在放入record数组的时候调用RecordDao类中的compare方法，实现放入的元素是有序的并且只显示前10个.
     *      最后调用RecordDao类中的writeRecord()方法，将record数组写入文件中保存
     * @return void
     */
    public void saveRecord(int record,String userName);

    /**
     * 实现放入的元素是有序(按分数从大到小)的并且只显示前10个:
     *              实现Comparator接口的匿名实现类，自定义排序方法，然后只保存前10个元素
     */
    public void compare(Record[] record,String userName);

    /**
     * 在控制台上打印record数组
     */
    public void viewRecord();

    /**IO
     * 将record数组写回到文件中保存
     */
    public void writeRecord() throws IOException;

    /**IO
     * 从文件中读取排行榜数组，保存到上面的record数组中
     */
    public void readRecord() throws IOException, ClassNotFoundException;
}


